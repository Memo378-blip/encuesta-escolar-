const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY;

const db = new Database(process.env.DB_FILE || "respuestas.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS respuestas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    student_name TEXT NOT NULL,
    answers TEXT NOT NULL
  )
`);

// Add the name column when upgrading a database created by the previous version.
const columns = db.prepare("PRAGMA table_info(respuestas)").all().map(c => c.name);
if (!columns.includes("student_name")) {
  db.exec("ALTER TABLE respuestas ADD COLUMN student_name TEXT NOT NULL DEFAULT 'Sin nombre'");
}

app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

const necesidades = [
  "Falta de agua en los baños",
  "Mantenimiento de los baños",
  "Implementación de comedores escolares",
  "Mantenimiento de salones",
  "Reparación de instalaciones escolares",
  "Mejoramiento de la seguridad",
  "Implementación de material escolar",
  "Mantenimiento de áreas verdes"
];
const opciones = [
  "No es muy necesario",
  "Estaría bien su mantenimiento o implementación",
  "Requiere urgentemente"
];

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "API disponible" });
});

app.post("/api/responses", (req, res) => {
  const studentName = typeof (req.body && req.body.studentName) === "string"
    ? req.body.studentName.trim().slice(0, 100) : "";
  const answers = req.body && req.body.answers;
  if (!studentName) {
    return res.status(400).json({ ok: false, error: "Escribe el nombre del estudiante." });
  }
  if (!Array.isArray(answers) || answers.length !== necesidades.length) {
    return res.status(400).json({ ok: false, error: "La encuesta está incompleta." });
  }

  for (let i = 0; i < necesidades.length; i++) {
    if (answers[i] !== opciones[0] && answers[i] !== opciones[1] && answers[i] !== opciones[2]) {
      return res.status(400).json({ ok: false, error: `Respuesta inválida en: ${necesidades[i]}` });
    }
  }

  const result = db.prepare("INSERT INTO respuestas (student_name, answers) VALUES (?, ?)")
    .run(studentName, JSON.stringify(answers));

  res.status(201).json({
    ok: true,
    message: "Respuestas guardadas correctamente.",
    responseId: Number(result.lastInsertRowid)
  });
});

app.get("/api/summary", (req, res) => {
  if (!ADMIN_KEY || req.get("x-admin-key") !== ADMIN_KEY) {
    return res.status(401).json({ ok: false, error: "No autorizado." });
  }

  const rows = db.prepare("SELECT id, student_name, created_at, answers FROM respuestas ORDER BY id ASC").all();
  const summary = necesidades.map((need, i) => {
    const counts = [0, 0, 0];
    for (const row of rows) {
      const answers = JSON.parse(row.answers);
      const index = opciones.indexOf(answers[i]);
      if (index >= 0) counts[index]++;
    }
    return {
      necesidad: need,
      noEsMuyNecesario: counts[0],
      estariaBien: counts[1],
      urgente: counts[2]
    };
  });

  res.json({
    ok: true,
    totalRespuestas: rows.length,
    participantes: rows.map(row => ({
      folio: row.id,
      nombre: row.student_name,
      fecha: row.created_at,
      respuestas: JSON.parse(row.answers)
    })),
    resultados: summary
  });
});

app.listen(PORT, () => {
  console.log(`Encuesta disponible en http://localhost:${PORT}`);
});