# Encuesta escolar con servidor y base de datos

## Qué incluye
- Página web adaptable a celular y computadora.
- Campo obligatorio para el nombre del estudiante; se guarda junto con sus respuestas.
- API `POST /api/responses` que valida y guarda las 8 respuestas.
- Base de datos SQLite en el archivo `respuestas.sqlite`.
- Confirmación visible con folio solo después de que la base de datos confirma el guardado.
- Resumen estadístico protegido por una clave de administrador.

## Requisitos
Instala Node.js 18 o superior en una computadora. Un archivo HTML abierto directamente no puede guardar respuestas en un servidor por sí solo.

## Ejecutar localmente
1. Descomprime el proyecto.
2. Abre una terminal dentro de la carpeta.
3. Ejecuta `npm install`.
4. Define una clave de administración:
   - macOS/Linux: `ADMIN_KEY="pon-una-clave-larga" npm start`
   - Windows PowerShell: `$env:ADMIN_KEY="pon-una-clave-larga"; npm start`
5. Abre `http://localhost:3000`.

La base de datos se crea automáticamente como `respuestas.sqlite` en la carpeta del servidor.

## Consultar resultados
Envía una petición GET a `/api/summary` incluyendo el encabezado `x-admin-key` con el valor de `ADMIN_KEY`. La respuesta incluye el total de encuestas y los conteos de cada opción por necesidad.

Ejemplo con curl:
`curl -H "x-admin-key: pon-una-clave-larga" http://localhost:3000/api/summary`

## Publicar para que respondan desde otros celulares
Sube el proyecto a un servicio que permita ejecutar Node.js y configura:
- Comando de inicio: `npm start`
- Variable `ADMIN_KEY`: una clave larga y privada.
- Almacenamiento persistente para `respuestas.sqlite`.

Importante: algunos alojamientos eliminan archivos locales al reiniciar o volver a desplegar. En ese caso configura un disco persistente o cambia SQLite por una base de datos administrada. Usa HTTPS y no compartas la clave de administración.

## Privacidad
La encuesta no pide nombres ni datos personales. Informa a los participantes quién analizará los resultados y para qué se utilizarán.
